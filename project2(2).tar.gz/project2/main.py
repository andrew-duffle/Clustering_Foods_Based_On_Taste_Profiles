#!/usr/bin/env python
#-*- coding: utf-8 -*-

import project2
from project2 import project2

def main():
    ##### Create clusters and plot the datum
    project2.ClusterPlot()

    
if __name__=='__main__':
    main()
